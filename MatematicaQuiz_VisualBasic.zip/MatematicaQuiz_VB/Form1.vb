Imports System
Imports System.Collections.Generic
Imports System.Drawing
Imports System.Windows.Forms

Public Class Form1
    Inherits Form

    Private ReadOnly panelMenu As New Panel()
    Private ReadOnly panelJuego As New Panel()
    Private ReadOnly panelResultado As New Panel()

    Private cmbTema As New ComboBox()
    Private nudTiempo As New NumericUpDown()
    Private nudCantidad As New NumericUpDown()
    Private btnIniciar As New Button()
    Private btnSalir As New Button()

    Private lblTema As New Label()
    Private lblPregunta As New Label()
    Private lblNumeroPregunta As New Label()
    Private lblTiempo As New Label()
    Private barraProgreso As New ProgressBar()

    Private respuestaA As New Button()
    Private respuestaB As New Button()
    Private respuestaC As New Button()
    Private respuestaD As New Button()
    Private ReadOnly timerJuego As New Timer()

    Private lblResumen As New Label()
    Private lblPorcentaje As New Label()
    Private btnJugarOtraVez As New Button()
    Private btnVolverMenu As New Button()

    Private preguntas As List(Of Pregunta)
    Private indice As Integer
    Private segundos As Integer
    Private correctas As Integer
    Private incorrectas As Integer
    Private totalPreguntas As Integer

    Private Class Pregunta
        Public Texto As String
        Public Opciones As String()
        Public Correcta As Integer
        Public Sub New(textoPregunta As String, opcionesPregunta As String(), respuestaCorrecta As Integer)
            Texto = textoPregunta
            Opciones = opcionesPregunta
            Correcta = respuestaCorrecta
        End Sub
    End Class

    Public Sub New()
        Me.Text = "MATEMÁTICA QUIZ"
        Me.StartPosition = FormStartPosition.CenterScreen
        Me.ClientSize = New Size(760, 560)
        Me.MinimumSize = New Size(700, 520)
        Me.BackColor = Color.FromArgb(239, 245, 255)
        CrearMenu()
        CrearJuego()
        CrearResultados()
        CrearPreguntas()
        timerJuego.Interval = 1000
        AddHandler timerJuego.Tick, AddressOf TimerJuego_Tick
        MostrarPanel(panelMenu)
    End Sub

    Private Sub PrepararPanel(p As Panel)
        p.Dock = DockStyle.Fill
        p.BackColor = Color.FromArgb(239, 245, 255)
        Me.Controls.Add(p)
    End Sub

    Private Function Etiqueta(texto As String, x As Integer, y As Integer, ancho As Integer, alto As Integer, tamano As Single, negrita As Boolean) As Label
        Dim l As New Label()
        l.Text = texto
        l.Location = New Point(x, y)
        l.Size = New Size(ancho, alto)
        l.Font = New Font("Segoe UI", tamano, If(negrita, FontStyle.Bold, FontStyle.Regular))
        l.ForeColor = Color.FromArgb(27, 55, 95)
        l.TextAlign = ContentAlignment.MiddleCenter
        Return l
    End Function

    Private Function Boton(texto As String, x As Integer, y As Integer, ancho As Integer, alto As Integer, colorFondo As Color) As Button
        Dim b As New Button()
        b.Text = texto
        b.Location = New Point(x, y)
        b.Size = New Size(ancho, alto)
        b.Font = New Font("Segoe UI", 11, FontStyle.Bold)
        b.BackColor = colorFondo
        b.ForeColor = Color.FromArgb(25, 45, 75)
        b.FlatStyle = FlatStyle.Flat
        b.FlatAppearance.BorderSize = 1
        b.Cursor = Cursors.Hand
        Return b
    End Function

    Private Sub CrearMenu()
        PrepararPanel(panelMenu)
        Dim titulo = Etiqueta("MATEMÁTICA" & Environment.NewLine & "QUIZ", 170, 30, 420, 105, 27, True)
        titulo.BackColor = Color.FromArgb(32, 78, 135)
        titulo.ForeColor = Color.White
        panelMenu.Controls.Add(titulo)
        panelMenu.Controls.Add(Etiqueta("¡Pon a prueba tus conocimientos!", 140, 145, 480, 35, 14, False))
        panelMenu.Controls.Add(Etiqueta("Selecciona el tema:", 170, 200, 180, 30, 11, True))
        cmbTema.DropDownStyle = ComboBoxStyle.DropDownList
        cmbTema.Items.AddRange(New Object() {"Aritmética", "Álgebra", "Geometría", "Razonamiento matemático"})
        cmbTema.SelectedIndex = 0
        cmbTema.Location = New Point(360, 202)
        cmbTema.Size = New Size(230, 30)
        cmbTema.Font = New Font("Segoe UI", 11)
        panelMenu.Controls.Add(cmbTema)
        panelMenu.Controls.Add(Etiqueta("Tiempo por pregunta:", 170, 250, 180, 30, 11, True))
        nudTiempo.Location = New Point(360, 252)
        nudTiempo.Size = New Size(100, 30)
        nudTiempo.Minimum = 5
        nudTiempo.Maximum = 60
        nudTiempo.Value = 15
        panelMenu.Controls.Add(nudTiempo)
        panelMenu.Controls.Add(Etiqueta("Cantidad de preguntas:", 170, 295, 180, 30, 11, True))
        nudCantidad.Location = New Point(360, 297)
        nudCantidad.Size = New Size(100, 30)
        nudCantidad.Minimum = 1
        nudCantidad.Maximum = 4
        nudCantidad.Value = 4
        panelMenu.Controls.Add(nudCantidad)
        btnIniciar = Boton("▶  INICIAR JUEGO", 210, 360, 220, 48, Color.FromArgb(55, 180, 100))
        btnSalir = Boton("Salir", 450, 360, 110, 48, Color.FromArgb(245, 105, 105))
        panelMenu.Controls.Add(btnIniciar)
        panelMenu.Controls.Add(btnSalir)
        AddHandler btnIniciar.Click, AddressOf IniciarJuego
        AddHandler btnSalir.Click, Sub() Me.Close()
    End Sub

    Private Sub CrearJuego()
        PrepararPanel(panelJuego)
        lblTema.Location = New Point(25, 18)
        lblTema.Size = New Size(300, 38)
        lblTema.Font = New Font("Segoe UI", 20, FontStyle.Bold)
        lblTema.ForeColor = Color.FromArgb(30, 65, 115)
        panelJuego.Controls.Add(lblTema)
        lblNumeroPregunta = Etiqueta("Pregunta 1 de 5", 430, 20, 140, 35, 11, True)
        lblNumeroPregunta.BackColor = Color.White
        panelJuego.Controls.Add(lblNumeroPregunta)
        lblTiempo = Etiqueta("00:15", 585, 20, 120, 35, 17, True)
        lblTiempo.BackColor = Color.FromArgb(255, 230, 170)
        lblTiempo.ForeColor = Color.DarkRed
        panelJuego.Controls.Add(lblTiempo)
        lblPregunta = Etiqueta("Pregunta", 45, 90, 660, 90, 19, True)
        lblPregunta.BackColor = Color.White
        panelJuego.Controls.Add(lblPregunta)
        respuestaA = Boton("A", 55, 215, 300, 60, Color.FromArgb(255, 190, 195))
        respuestaB = Boton("B", 390, 215, 300, 60, Color.FromArgb(175, 215, 255))
        respuestaC = Boton("C", 55, 290, 300, 60, Color.FromArgb(180, 240, 190))
        respuestaD = Boton("D", 390, 290, 300, 60, Color.FromArgb(255, 225, 150))
        panelJuego.Controls.AddRange(New Control() {respuestaA, respuestaB, respuestaC, respuestaD})
        AddHandler respuestaA.Click, Sub() Responder(0)
        AddHandler respuestaB.Click, Sub() Responder(1)
        AddHandler respuestaC.Click, Sub() Responder(2)
        AddHandler respuestaD.Click, Sub() Responder(3)
        barraProgreso.Location = New Point(55, 385)
        barraProgreso.Size = New Size(635, 25)
        barraProgreso.Minimum = 0
        barraProgreso.Maximum = 100
        panelJuego.Controls.Add(barraProgreso)
    End Sub

    Private Sub CrearResultados()
        PrepararPanel(panelResultado)
        Dim titulo = Etiqueta("🏆  ¡JUEGO TERMINADO!", 100, 35, 560, 60, 24, True)
        panelResultado.Controls.Add(titulo)
        lblResumen = Etiqueta("", 120, 130, 520, 130, 16, True)
        lblResumen.BackColor = Color.White
        panelResultado.Controls.Add(lblResumen)
        lblPorcentaje = Etiqueta("", 120, 275, 520, 45, 16, True)
        panelResultado.Controls.Add(lblPorcentaje)
        btnJugarOtraVez = Boton("↻  Jugar de nuevo", 145, 370, 210, 50, Color.FromArgb(255, 205, 100))
        btnVolverMenu = Boton("⌂  Volver al menú", 385, 370, 210, 50, Color.FromArgb(115, 175, 245))
        panelResultado.Controls.Add(btnJugarOtraVez)
        panelResultado.Controls.Add(btnVolverMenu)
        AddHandler btnJugarOtraVez.Click, AddressOf IniciarJuego
        AddHandler btnVolverMenu.Click, Sub() MostrarPanel(panelMenu)
    End Sub

    Private Sub CrearPreguntas()
        preguntas = New List(Of Pregunta)()
        Select Case cmbTema.Text
            Case "Álgebra"
                preguntas.Add(New Pregunta("Si x + 7 = 15, ¿cuánto vale x?", New String() {"6", "7", "8", "9"}, 2))
                preguntas.Add(New Pregunta("Simplifica: 3x + 2x", New String() {"5", "5x", "6x", "x5"}, 1))
                preguntas.Add(New Pregunta("Si 2x = 18, ¿cuánto vale x?", New String() {"7", "8", "9", "10"}, 2))
                preguntas.Add(New Pregunta("¿Cuál es el valor de 4²?", New String() {"8", "12", "16", "20"}, 2))
                preguntas.Add(New Pregunta("Resuelve: x − 6 = 11", New String() {"5", "15", "17", "18"}, 2))
                preguntas.Add(New Pregunta("Simplifica: 7a − 3a", New String() {"4", "4a", "10a", "21a"}, 1))
                preguntas.Add(New Pregunta("Si y = 3, ¿cuánto vale 2y + 5?", New String() {"8", "10", "11", "13"}, 2))
                preguntas.Add(New Pregunta("Resuelve: 5x = 35", New String() {"5", "6", "7", "8"}, 2))
                preguntas.Add(New Pregunta("¿Cuál es el resultado de (x + 2) si x = 9?", New String() {"7", "11", "18", "20"}, 1))
                preguntas.Add(New Pregunta("¿Qué expresión representa el doble de n?", New String() {"n + 2", "n²", "2n", "n ÷ 2"}, 2))
            Case "Geometría"
                preguntas.Add(New Pregunta("¿Cuántos lados tiene un hexágono?", New String() {"5", "6", "7", "8"}, 1))
                preguntas.Add(New Pregunta("¿Cuánto suman los ángulos interiores de un triángulo?", New String() {"90°", "180°", "270°", "360°"}, 1))
                preguntas.Add(New Pregunta("¿Cuál es el área de un rectángulo de 5 cm por 3 cm?", New String() {"8 cm²", "15 cm²", "16 cm²", "30 cm²"}, 1))
                preguntas.Add(New Pregunta("¿Cuántos grados tiene un ángulo recto?", New String() {"45°", "90°", "180°", "360°"}, 1))
                preguntas.Add(New Pregunta("¿Cuál es el perímetro de un cuadrado de lado 4 cm?", New String() {"8 cm", "12 cm", "16 cm", "20 cm"}, 2))
                preguntas.Add(New Pregunta("¿Cuántos vértices tiene un cubo?", New String() {"6", "8", "10", "12"}, 1))
                preguntas.Add(New Pregunta("¿Cuál es el área de un cuadrado de lado 6 cm?", New String() {"12 cm²", "24 cm²", "30 cm²", "36 cm²"}, 3))
                preguntas.Add(New Pregunta("¿Cómo se llama un polígono de 8 lados?", New String() {"Pentágono", "Hexágono", "Heptágono", "Octágono"}, 3))
                preguntas.Add(New Pregunta("¿Cuántos centímetros hay en 1 metro?", New String() {"10", "100", "1000", "50"}, 1))
                preguntas.Add(New Pregunta("¿Cuál es la fórmula del área de un triángulo?", New String() {"base × altura", "(base × altura) ÷ 2", "lado × 4", "base + altura"}, 1))
            Case "Razonamiento matemático"
                preguntas.Add(New Pregunta("¿Qué número sigue? 2, 4, 6, 8, ...", New String() {"9", "10", "11", "12"}, 1))
                preguntas.Add(New Pregunta("Si hoy es lunes, ¿qué día será dentro de 3 días?", New String() {"Martes", "Miércoles", "Jueves", "Viernes"}, 2))
                preguntas.Add(New Pregunta("¿Cuál número no pertenece al grupo: 2, 4, 6, 9, 8?", New String() {"2", "4", "6", "9"}, 3))
                preguntas.Add(New Pregunta("Ana tiene 3 bolsas con 4 manzanas cada una. ¿Cuántas tiene?", New String() {"7", "9", "12", "15"}, 2))
                preguntas.Add(New Pregunta("¿Qué número sigue? 5, 10, 15, 20, ...", New String() {"22", "24", "25", "30"}, 2))
                preguntas.Add(New Pregunta("Si 3 lápices cuestan S/ 6, ¿cuánto cuesta 1 lápiz?", New String() {"S/ 1", "S/ 2", "S/ 3", "S/ 6"}, 1))
                preguntas.Add(New Pregunta("¿Cuál es la mitad de 46?", New String() {"21", "22", "23", "24"}, 2))
                preguntas.Add(New Pregunta("Un reloj marca las 2:00. ¿Qué hora será en 4 horas?", New String() {"4:00", "5:00", "6:00", "8:00"}, 2))
                preguntas.Add(New Pregunta("¿Qué número falta? 10, 20, __, 40", New String() {"25", "28", "30", "35"}, 2))
                preguntas.Add(New Pregunta("Hay 12 caramelos para 4 niños por igual. ¿Cuántos recibe cada uno?", New String() {"2", "3", "4", "6"}, 1))
            Case Else
                preguntas.Add(New Pregunta("¿Cuánto es 25 × 6?", New String() {"120", "130", "140", "150"}, 0))
                preguntas.Add(New Pregunta("¿Cuánto es 48 ÷ 6?", New String() {"6", "7", "8", "9"}, 2))
                preguntas.Add(New Pregunta("¿Cuánto es 15 + 27?", New String() {"32", "42", "52", "40"}, 1))
                preguntas.Add(New Pregunta("¿Cuánto es 9 × 9?", New String() {"72", "81", "89", "99"}, 1))
                preguntas.Add(New Pregunta("¿Cuánto es 100 − 36?", New String() {"54", "64", "74", "66"}, 1))
                preguntas.Add(New Pregunta("¿Cuál es el doble de 18?", New String() {"26", "32", "36", "38"}, 2))
                preguntas.Add(New Pregunta("¿Cuánto es 7 × 8?", New String() {"54", "56", "58", "64"}, 1))
                preguntas.Add(New Pregunta("¿Cuánto es 81 ÷ 9?", New String() {"7", "8", "9", "10"}, 2))
                preguntas.Add(New Pregunta("¿Cuánto es 35 + 19?", New String() {"44", "54", "64", "52"}, 1))
                preguntas.Add(New Pregunta("¿Cuánto es 12 × 4?", New String() {"36", "42", "48", "52"}, 2))
        End Select
    End Sub

    Private Sub MostrarPanel(panelVisible As Panel)
        panelMenu.Visible = (panelVisible Is panelMenu)
        panelJuego.Visible = (panelVisible Is panelJuego)
        panelResultado.Visible = (panelVisible Is panelResultado)
        panelVisible.BringToFront()
    End Sub

    Private Sub IniciarJuego(sender As Object, e As EventArgs)
        timerJuego.Stop()
        CrearPreguntas()
        Dim cantidad As Integer = CInt(nudCantidad.Value)
        preguntas = preguntas.GetRange(0, Math.Min(cantidad, preguntas.Count))
        totalPreguntas = preguntas.Count
        indice = 0
        correctas = 0
        incorrectas = 0
        MostrarPanel(panelJuego)
        CargarPregunta()
    End Sub

    Private Sub CargarPregunta()
        If indice >= totalPreguntas Then
            TerminarJuego()
            Return
        End If
        Dim p = preguntas(indice)
        lblTema.Text = cmbTema.Text
        lblPregunta.Text = p.Texto
        lblNumeroPregunta.Text = "Pregunta " & (indice + 1).ToString() & " de " & totalPreguntas.ToString()
        respuestaA.Text = "A     " & p.Opciones(0)
        respuestaB.Text = "B     " & p.Opciones(1)
        respuestaC.Text = "C     " & p.Opciones(2)
        respuestaD.Text = "D     " & p.Opciones(3)
        segundos = CInt(nudTiempo.Value)
        ActualizarTiempo()
        barraProgreso.Value = CInt((indice / CDbl(totalPreguntas)) * 100)
        timerJuego.Start()
    End Sub

    Private Sub TimerJuego_Tick(sender As Object, e As EventArgs)
        segundos -= 1
        ActualizarTiempo()
        If segundos <= 0 Then
            timerJuego.Stop()
            incorrectas += 1
            indice += 1
            CargarPregunta()
        End If
    End Sub

    Private Sub ActualizarTiempo()
        lblTiempo.Text = "00:" & segundos.ToString("00")
    End Sub

    Private Sub Responder(opcion As Integer)
        If Not timerJuego.Enabled OrElse indice >= totalPreguntas Then Return
        timerJuego.Stop()
        If opcion = preguntas(indice).Correcta Then
            correctas += 1
        Else
            incorrectas += 1
        End If
        indice += 1
        CargarPregunta()
    End Sub

    Private Sub TerminarJuego()
        timerJuego.Stop()
        barraProgreso.Value = 100
        Dim porcentaje As Integer = CInt((correctas / CDbl(totalPreguntas)) * 100)
        lblResumen.Text = "Respuestas correctas: " & correctas.ToString() & Environment.NewLine &
                          "Respuestas incorrectas: " & incorrectas.ToString() & Environment.NewLine &
                          "Puntaje obtenido: " & (correctas * 5).ToString() & " de 20 puntos"
        lblPorcentaje.Text = "Porcentaje de aciertos: " & porcentaje.ToString() & "%"
        MostrarPanel(panelResultado)
    End Sub
End Class
